(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:jquery-easing'] = {};

})();

//# sourceMappingURL=mrt_jquery-easing.js.map
