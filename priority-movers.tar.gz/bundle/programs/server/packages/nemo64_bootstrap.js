(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nemo64:bootstrap'] = {};

})();

//# sourceMappingURL=nemo64_bootstrap.js.map
