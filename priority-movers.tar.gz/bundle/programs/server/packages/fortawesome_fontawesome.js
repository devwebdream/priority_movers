(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['fortawesome:fontawesome'] = {};

})();

//# sourceMappingURL=fortawesome_fontawesome.js.map
